print("helo dunia!!!!!!!")
print("apa kabar kalian?")
print("instalasi berhasil")