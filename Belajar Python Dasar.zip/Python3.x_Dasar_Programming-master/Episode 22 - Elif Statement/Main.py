# ELIF = else if statement

nama = input("Nama kamyu siapa? ")

if nama == "ucup": # kondisi 1
	print("Hai ganteeeeng beuds!") # aksi true 1
elif nama == "otong": # kondisi 2
	print("Hai si kece bangeeeets!!") # aksi true 2
elif nama == "mario": # kondisi 3
	print("Hai humooooreeeesh!") # aksi true 3
else:
	print("au ah gak kenal!!!") # aksi false

print("ini adalah akhir dari program")