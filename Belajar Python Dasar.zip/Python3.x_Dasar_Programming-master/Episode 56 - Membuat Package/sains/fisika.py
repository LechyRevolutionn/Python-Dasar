''' module fisika '''

def gaya(m,a):
    return m*a