def pangkat(n):
    return lambda angka:angka**n