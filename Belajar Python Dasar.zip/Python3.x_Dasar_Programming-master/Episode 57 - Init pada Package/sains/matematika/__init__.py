from . import basic
from . import scientific

from .basic import tambah,kali
from .scientific import pangkat